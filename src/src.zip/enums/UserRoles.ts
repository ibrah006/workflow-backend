export enum UserRole {
    MANAGER = 'manager',
    VIEWER = 'viewer',
  }